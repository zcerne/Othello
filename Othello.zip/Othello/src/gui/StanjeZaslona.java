package gui;

public enum StanjeZaslona {
	MENU, IGRA
}
