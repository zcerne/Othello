package gui;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import javax.swing.JPanel;

import logika.Igra;
import logika.Igralec;
import logika.Polje;
import splosno.Poteza;
import vodja.Vodja;
import vodja.VrstaIgralca;

public class Platno extends JPanel implements MouseListener, MouseMotionListener, KeyListener{
	
	int sizeX, sizeY;
	
	Igra igra;
	Color barvaOzadja;
	
	ArrayList<Poteza> izberi;
	
	private ArrayList<Gumb> gumbi;
	public Platno() {
		super();
		
		//igra = new Igra();
		
		sizeX = sizeY = 600; //velikost okna
		
		setPreferredSize(new Dimension(sizeX, sizeY));
		
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.addKeyListener(this);
		this.setFocusable(true);
		
		barvaOzadja = Color.BLUE;
		
		this.setBackground(barvaOzadja);
		gumbi = new ArrayList<Gumb>();
		
		ustvariGumbe();
		//repaint();
		

	}
	
	private int kvadratek() {
		return Math.min(getWidth(), getHeight()) / Igra.N;
	}
	
	protected void paintComponent(Graphics g1) {
		
		Graphics2D g = (Graphics2D)g1;
		super.paintComponent(g);
		if(Vodja.stanjeZaslona == StanjeZaslona.MENU) {
			//ustvariGumbe();
			narisiGumbeMenu(g);
			
		}
		
		else if(Vodja.stanjeZaslona == StanjeZaslona.IGRA) {
			narisiPlosco(g);
			narisiMoznosti(g);
		}
		
	}
	public void narisiGumbeMenu(Graphics2D g) {
		for(Gumb gu : gumbi) {
			gu.narisi(g);
		}
	}
	
	public void ustvariGumbe() {
		int w = this.getSize().width;
		int h = this.getSize().height;
		
		Gumb g1 = new Gumb(VrstaGumba.II, w/2 - w/4, 1*h/5, w/2, h/16);
		gumbi.add(g1);
		gumbi.add(new Gumb(VrstaGumba.IR, w/2 - w/4, 2*h/5, w/2, h/16));
		gumbi.add(new Gumb(VrstaGumba.RI, w/2 - w/4, 3*h/5, w/2, h/16));
		gumbi.add(new Gumb(VrstaGumba.RR, w/2 - w/4, 4*h/5, w/2, h/16));
		Gumb gumbUndo = new Gumb(VrstaGumba.UNDO, w/2 - w/4, 1*h/5, w/2, h/16);

		//gumbi.add(g2);
		//gumbi.add(g3);
		//gumbi.add(g4);
		System.out.println("lol");
	}
	
	public void narisiPlosco(Graphics2D g) {
		//gre čez celotno ploščo in nariše krog z barvo glede na vrednost v matriki pl0šče....................
		
		int a = kvadratek();
		for (int i = 0; i < Igra.N; i++) {
			for (int j = 0; j < Igra.N; j++) {
				//g.setColor(barvaOzadja);
				//g.fillRect(i*a, j*a, a, a);
				g.setColor(Color.black);
				g.drawRect(i*a, j*a, a, a);
				
				//uglavnem rišem ploščo
				//to je mal chonky narjen ker ne razumem kaj pomeni statična metoda. Prej je pisal Vodja.igra[i][j]
				if (Vodja.igra.getPlosca()[i][j] == Polje.BEL) {
					g.setColor(Color.white);
					g.fillOval(i*a + a/4, j*a + a/4, a/2, a/2);
				}
				else if (Vodja.igra.getPlosca()[i][j] == Polje.CRN) {
					g.setColor(Color.black);
					g.fillOval(i*a + a/4, j*a + a/4, a/2, a/2);
				}
				
				
			}
		}
		
	}
	
	//narišem kam lahko uturim krogec
	public void narisiMoznosti(Graphics2D g) {
		//gre čez vse koordinate v izberi in jih nariše
		int a = kvadratek();
		izberi = Vodja.igra.dovoljenePoteze();
		if (izberi != null) {
			
			for(Poteza pol : izberi) {
				int i = pol.getX();
				int j = pol.getY();
				g.setColor(Color.black);
				g.drawOval(i*a + a/4, j*a + a/4, a/2, a/2);
			}
		}
	}

			
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		int moseX = e.getX();
		int moseY = e.getY();
		
		switch(Vodja.stanjeZaslona) {
		case MENU : 
			for(Gumb g : gumbi) {
				if(g.klik(moseX, moseY)) {
					Vodja.dolociIgralce(g.ime);
					
					
				}
			}
			
			break;
			
		case IGRA :

			int a = kvadratek();

			
			//za vsako polje preveri ali smo kliknili nanj in potem kliče izvediPotezo, 
			if(Vodja.clovekNaPotezi) {
				for (int i = 0; i < 8; i++) {
					for (int j = 0; j < 8; j++) {
						if ((i*a <= moseX && moseX < i*a+a) && (j*a <= moseY && moseY < j*a + a)) {
							//System.out.println("Pred iskanjem");
							Poteza poteza = new Poteza(i,j);
							
							
							Vodja.igrajPotezo(poteza);
						}
	
					}
				}
			}
			break;
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == 85) {
			int ind = Vodja.zgodovina.size() - 1;
			System.out.println("U");
			int di = 0;
				if(Vodja.vrstaIgralca.get(Igralec.CRN) == VrstaIgralca.R || Vodja.vrstaIgralca.get(Igralec.BEL) == VrstaIgralca.R) di = 2;
				else if (Vodja.vrstaIgralca.get(Igralec.CRN) == VrstaIgralca.C && Vodja.vrstaIgralca.get(Igralec.BEL) == VrstaIgralca.C) di = 1;
				
				if(ind >= di) {
				System.out.println("undo?");
				Vodja.igra = new Igra(Vodja.zgodovina.get(ind-di));
				Vodja.zgodovina.remove(ind);
				if(di == 2) Vodja.zgodovina.remove(ind-1);
				Vodja.igramo();
				}
			}
				
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
