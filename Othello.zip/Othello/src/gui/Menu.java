package gui;

import javax.swing.JButton;

public class Menu {
	
	public JButton b1 = new JButton("Igra");
	public void prikaziMenu() {
		
	}
}
