package logika;

public enum Stanje {
NEODLOCENO, ZMAGA_CRN, ZMAGA_BEL, V_TEKU
}
