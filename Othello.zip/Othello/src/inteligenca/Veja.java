package inteligenca;

import logika.Igra;

public class Veja {
	
	private Igra igra;
	private double wins;
	private int visits;

	public List(Igra igra, int visits, double wins) {
		this.igra = igra;
		this.visits = visits;
		this.wins = wins;
		
		
	}
}
