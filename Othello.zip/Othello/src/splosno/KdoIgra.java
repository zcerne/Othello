package splosno;

public class KdoIgra {
	
	// ime igralca
	private String ime;
	
	public KdoIgra(String ime) {
		this.ime = ime;
	}
	
	@Override
	public String toString() {
		return ime;
	}

}
